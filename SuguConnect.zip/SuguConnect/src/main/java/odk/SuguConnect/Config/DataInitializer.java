package odk.SuguConnect.Config;

import odk.SuguConnect.Entity.Admin;
import odk.SuguConnect.Enums.Role;
import odk.SuguConnect.Repository.AdminRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

@Configuration
public class DataInitializer {

    @Value("${admin.nom:Super}")
    private String adminNom;

    @Value("${admin.prenom:Admin}")
    private String adminPrenom;

    @Value("${admin.email:admin@suguconnect.com}")
    private String adminEmail;

    @Value("${admin.telephone:70000000}")
    private String adminTelephone;

    @Value("${admin.password:admin123}")
    private String adminPassword;

    private final AdminRepository adminRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(AdminRepository adminRepository, PasswordEncoder passwordEncoder) {
        this.adminRepository = adminRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Bean
    @Transactional
    public CommandLineRunner initAdmin() {
        return args -> {
            // Vérifie si un admin existe déjà
            if (adminRepository.findByTelephone(adminTelephone) == null) {
                Admin admin = new Admin();
                admin.setNom(adminNom);
                admin.setPrenom(adminPrenom);
                admin.setEmail(adminEmail);
                admin.setTelephone(adminTelephone);
                admin.setMotDePasse(passwordEncoder.encode(adminPassword));
                admin.setRole(Role.ADMIN);
                admin.setDateInscription(LocalDate.now());
                admin.setActif(true);

                adminRepository.save(admin);
                System.out.println(" Admin par défaut créé avec succès !");
            }
        };
    }
}
