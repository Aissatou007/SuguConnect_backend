package odk.SuguConnect.Controller;

import odk.SuguConnect.Entity.Categorie;
import odk.SuguConnect.Entity.Produit;
import odk.SuguConnect.Service.CategorieService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping(path = "/categorie")
public class CategorieController {
    private final CategorieService categorieService;

    public CategorieController(CategorieService categorieService) {
        this.categorieService = categorieService;
    }

    @PreAuthorize("hasRole('ADMIN')") // Correction : hasRole avec 'R' majuscule
    @PostMapping
    public ResponseEntity<Categorie> creerCategorie(
            @RequestParam String libelle,
            @RequestParam MultipartFile photo) {
        try {
            Categorie categorie = categorieService.creerCategorie(libelle, photo);
            return ResponseEntity.ok(categorie);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping(path = "/{id}") // Ajouter la méthode pour modifier une catégorie
    public ResponseEntity<Categorie> modifierCategorie(
            @PathVariable int id,
            @RequestBody Categorie categorie) {
        Categorie categorieModifiee = categorieService.modifierCategorie(id, categorie);
        return ResponseEntity.ok(categorieModifiee);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping(path = "/{id}")
    public ResponseEntity<String> supprimerCategorie(@PathVariable int id) {
        return ResponseEntity.ok(categorieService.supprimerCategorie(id));
    }

    @GetMapping
    public ResponseEntity<List<Categorie>> toutesLesCategories() {
        return ResponseEntity.ok(categorieService.listerCategorie());
    }

    @GetMapping(path = "/{id}")
    public ResponseEntity<Categorie> categorieParId(@PathVariable int id) {
        return ResponseEntity.ok(categorieService.recupererUneCategorie(id));
    }

    @GetMapping(path = "/{id}/produits")
    public ResponseEntity<List<Produit>> produitsParCategorie(@PathVariable int id) {
        return ResponseEntity.ok(categorieService.listProduitParCategorie(id));
    }
}