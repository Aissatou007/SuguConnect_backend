package odk.SuguConnect.DTO.SimpleDTO;

import odk.SuguConnect.Entity.Paiement;
import odk.SuguConnect.Enums.StatutPaiement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PaiementRepository extends JpaRepository<Paiement, Integer> {
    List<Paiement> findByConsommateurIdConsommateur(Integer consommateurId);
    List<Paiement> findByStatutPaiement(StatutPaiement statut);
}